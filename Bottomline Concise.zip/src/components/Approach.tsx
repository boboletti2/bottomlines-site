const stats = [
  { k: "+38%", v: "Average margin lift for our restaurant clients in year one" },
  { k: "12 wk", v: "From first call to live site, clean books and a real forecast" },
  { k: "100%", v: "Of the businesses we've set up are still trading three years on" },
  { k: "1:1", v: "You talk to the people actually doing the work — not an account manager" },
];

export function Approach() {
  return (
    <section id="approach" className="hairline-b bg-foreground text-background">
      <div className="mx-auto max-w-[1440px] px-6 py-24 md:px-10 md:py-32">
        <div className="grid grid-cols-12 gap-6">
          <div className="col-span-12 md:col-span-9 md:col-start-4">
            <p className="font-display text-3xl font-medium leading-[1.15] tracking-tighter md:text-5xl">
              We treat your tiny business the way a fancy firm treats a series&nbsp;B —
              <span className="text-background/55">
                {" "}minus the deck, the jargon, and the retainer that quietly eats your runway.
              </span>
            </p>
          </div>
        </div>

        <div className="mt-20 grid grid-cols-12 gap-0 border-t border-background/15">
          {stats.map((s) => (
            <div
              key={s.k}
              className="col-span-6 border-b border-background/15 px-0 py-10 md:col-span-3 md:border-r md:last:border-r-0 md:[&:nth-child(2)]:border-r md:py-14 md:pr-6"
            >
              <div className="font-display text-5xl font-bold tracking-tightest md:text-7xl">
                {s.k}
              </div>
              <p className="mt-6 max-w-[18ch] text-sm leading-relaxed text-background/65">
                {s.v}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
