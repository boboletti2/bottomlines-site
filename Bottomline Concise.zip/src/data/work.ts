import folkkok from "@/assets/work-folkkok.jpg";
import norra from "@/assets/work-norra.jpg";
import atlas from "@/assets/work-atlas.jpg";
import mobel from "@/assets/work-mobel.jpg";

export type WorkItem = {
  no: string;
  slug: string;
  name: string;
  cat: string;
  scope: string;
  year: string;
  quote: string;
  image: string;
  summary: string;
  services: string[];
  outcomes: { k: string; v: string }[];
  story: string[];
};

export const work: WorkItem[] = [
  {
    no: "W—01",
    slug: "folkkok",
    name: "Folkkök",
    cat: "Restaurant",
    scope: "Books · Forecast · Site",
    year: "2024",
    quote: "Opened a second location six months ahead of plan.",
    image: folkkok,
    summary:
      "A neighbourhood restaurant in Copenhagen with strong word-of-mouth and weak back-office. We rebuilt the books, modelled the second location, and shipped a site that finally matched the food.",
    services: ["Bookkeeping", "Forecasting", "Web design & build", "Menu pricing"],
    outcomes: [
      { k: "−6 mo", v: "Earlier opening of second location" },
      { k: "+14%", v: "Average ticket after menu reprice" },
      { k: "0", v: "Late VAT filings since handover" },
    ],
    story: [
      "Folkkök came to us nine months in: full house most nights, no idea if they were profitable. We started with a full reconciliation of the first year, then rebuilt the chart of accounts around the way the kitchen actually runs.",
      "From the cleaned-up baseline we modelled three scenarios for a second location and helped pick the lease. The new site launched alongside the opening — single page, real photography, a booking widget that doesn't get in the way.",
    ],
  },
  {
    no: "W—02",
    slug: "norra-studio",
    name: "Norra Studio",
    cat: "Online shop",
    scope: "Shopify · Brand · VAT",
    year: "2025",
    quote: "Cut fulfilment cost per order by 22% in one quarter.",
    image: norra,
    summary:
      "A homewares brand selling internationally from a small Copenhagen studio. We rebuilt the storefront on Shopify, untangled cross-border VAT, and tightened the fulfilment economics.",
    services: ["Shopify build", "Brand system", "EU & UK VAT", "Ops review"],
    outcomes: [
      { k: "−22%", v: "Fulfilment cost per order" },
      { k: "+1.8×", v: "Conversion rate after redesign" },
      { k: "4 mkts", v: "Compliant VAT setup across EU + UK" },
    ],
    story: [
      "Norra had outgrown a templated storefront and was leaking margin on shipping and returns. We replatformed onto a clean Shopify build with a tighter visual system, then reworked the packaging, carrier mix and VAT setup behind it.",
      "The result is a shop that converts better, ships cheaper, and files quietly in every market it sells in.",
    ],
  },
  {
    no: "W—03",
    slug: "atlas-coffee",
    name: "Atlas Coffee",
    cat: "Retail / café",
    scope: "Pricing · Site · Payroll",
    year: "2024",
    quote: "Three locations, one set of books, zero late filings.",
    image: atlas,
    summary:
      "Three café locations, three sets of spreadsheets, one very tired founder. We consolidated the books, redesigned pricing across the menu, and shipped a site that works as the brand's front door.",
    services: ["Consolidated bookkeeping", "Payroll", "Pricing strategy", "Website"],
    outcomes: [
      { k: "1", v: "Set of books across three locations" },
      { k: "+9%", v: "Gross margin after reprice" },
      { k: "100%", v: "On-time payroll and filings" },
    ],
    story: [
      "Atlas was running each location like its own company. We unified the books, built a payroll process the managers can actually run, and repriced the menu against real cost data.",
      "The new site ties the three rooms together — one identity, one story, one place to find opening hours that are always right.",
    ],
  },
  {
    no: "W—04",
    slug: "mobel-kollektiv",
    name: "Möbel Kollektiv",
    cat: "D2C brand",
    scope: "Headless web · Economics",
    year: "2026",
    quote: "From founder spreadsheet to investor-ready in ten weeks.",
    image: mobel,
    summary:
      "A young D2C furniture label preparing for a first raise. We took them from a single founder spreadsheet to an investor-grade model and a headless storefront built to scale with the catalogue.",
    services: ["Headless commerce", "Financial model", "Unit economics", "Investor pack"],
    outcomes: [
      { k: "10 wk", v: "From kickoff to investor-ready" },
      { k: "3-yr", v: "Driver-based forecast and cap table" },
      { k: "Headless", v: "Storefront built for international rollout" },
    ],
    story: [
      "Möbel Kollektiv had a strong product and a chaotic back office. We rebuilt the financial model from the unit up — landed cost, contribution margin, payback per channel — and produced the materials they needed to walk into a room of investors.",
      "Alongside the numbers we shipped a headless storefront on a stack their next CTO will actually want to inherit.",
    ],
  },
];

export function getWork(slug: string) {
  return work.find((w) => w.slug === slug);
}
